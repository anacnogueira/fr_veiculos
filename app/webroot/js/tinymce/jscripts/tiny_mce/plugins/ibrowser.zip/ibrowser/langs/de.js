// German lang variables
tinyMCE.addToLang('ibrowser', {
title: 'Bild hinzuf&uuml;gen/&auml;ndern',
desc:  'iBrowser'
});
