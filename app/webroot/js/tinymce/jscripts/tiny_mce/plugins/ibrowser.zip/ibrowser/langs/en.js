// English lang variables
tinyMCE.addToLang('ibrowser', {
title: 'Add/edit image',
desc:  'iBrowser'
});
