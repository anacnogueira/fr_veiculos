// French lang variables
tinyMCE.addToLang('ibrowser', {
title: 'Ajouter/modifier image',
desc:  'iBrowser'
});
